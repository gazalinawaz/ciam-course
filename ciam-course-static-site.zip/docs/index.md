# CIAM Architecture Course

Welcome to the **CIAM Architecture Course**.

## What you'll learn
- CIAM fundamentals and reference architectures
- Authentication and authorization patterns
- Fraud, risk, and device binding
- Migration strategies from legacy IAM

Use the navigation to start the course.
