# CIAM Architecture Course

This repository contains a **static CIAM Architecture Course** built using **MkDocs + Material**.

## Local Run
```bash
pip install mkdocs mkdocs-material
mkdocs serve
```

## Build
```bash
mkdocs build
```

## Deploy
- GitHub Pages
- Render (Static Site)
